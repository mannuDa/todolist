please run the 
composer install
npm install
npm run dev 

commands first to run the app